module.exports = {
  devServer: {
    disableHostCheck: true
  }
}
